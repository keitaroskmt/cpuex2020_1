#pragma once

int vliw_assign(int end);