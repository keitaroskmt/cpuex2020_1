#pragma once

void print_vliw(std::string out_file_name, std::string type);