#pragma once

int load_ops(FILE *fp);