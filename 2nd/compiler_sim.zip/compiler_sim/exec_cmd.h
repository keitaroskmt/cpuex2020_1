#pragma once

int exec_cmd(int *loop, bool *is_stat, bool *print_bc, bool *print_calc, bool *print_process);