#pragma once

void ftable_init();

extern std::vector<unsigned long long int> finv_table;
extern std::vector<unsigned long long int> fsqrt_table;