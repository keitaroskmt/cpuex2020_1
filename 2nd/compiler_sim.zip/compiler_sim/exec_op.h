#pragma once
#include "sim.h"

int exec_op(op_info op, bool print_calc, bool use_fpu);