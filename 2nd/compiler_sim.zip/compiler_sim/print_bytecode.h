#pragma once
#include "sim.h"

int print_bytecode(op_info op);